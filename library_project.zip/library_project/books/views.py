from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Book
from .serializers import BookSerializer


# Home page view to serve HTML
def home(request):
    return render(request, 'index.html')


# DRF ViewSet for CRUD operations
class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    
    @action(detail=False, methods=['get'])
    def available_books(self, request):
        """Get all available books"""
        books = Book.objects.filter(is_available=True)
        serializer = self.get_serializer(books, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def unavailable_books(self, request):
        """Get all unavailable books"""
        books = Book.objects.filter(is_available=False)
        serializer = self.get_serializer(books, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def set_availability(self, request, pk=None):
        """Toggle book availability"""
        book = self.get_object()
        book.is_available = request.data.get('is_available', book.is_available)
        book.save()
        serializer = self.get_serializer(book)
        return Response(serializer.data)

