from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BookViewSet, home

router = DefaultRouter()
router.register(r'books', BookViewSet)

urlpatterns = [
    path('', home, name='home'),
    path('api/', include(router.urls)),
]
