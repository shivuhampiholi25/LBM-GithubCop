from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)      # text, limited to 200 chars
    author = models.CharField(max_length=100)
    isbn = models.CharField(max_length=13, unique=True)  # unique = no duplicates
    published_year = models.IntegerField()
    is_available = models.BooleanField(default=True)  # Is it available to borrow?

    class Meta:
        ordering = ['-id']  # Order by newest first

    def __str__(self):
        return self.title   # When you print a Book object, shows its title